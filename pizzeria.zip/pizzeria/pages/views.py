'''
Name: Justin Theyskens
netID: jtheyskens
Student ID: 109558084
'''

from django.shortcuts import render
from pizzas.models import Pizza, Topping

# Create your views here.
def home(request):
    pizzas = Pizza.objects.all()
    context = {'pizzas' : pizzas}
    return render(request, 'home.html', context)
    #return render(request, 'home.html')
    
def toppings(request, pizza_id):
    pizza = Pizza.objects.get(id=pizza_id)
    toppings = pizza.topping_set.all()
    context = {'pizza': pizza, 'toppings' : toppings}
    return render(request, 'toppings.html', context)
